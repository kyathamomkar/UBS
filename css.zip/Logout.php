<?php
session_start();
unset($_SESSION['loggedinuser']);
session_destroy();

header("Location: /default.html");
exit;
?>